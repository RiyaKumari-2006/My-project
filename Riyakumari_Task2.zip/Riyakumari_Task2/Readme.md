# Laundry Wallah / Laundry Mart

## Project Description

Laundry Wallah / Laundry Mart is a simple HTML-based website created to showcase a laundry service business. The website provides information about the company, the services offered, pricing details, a booking section, and contact information.

## Features

* Welcome section
* About Laundry Mart
* Laundry service image
* List of available services
* Price list in table format
* Booking form with Name, Email, and Phone fields
* Footer with contact details

## Technologies Used

* HTML5

## Project Structure

```
Laundry-Mart/
│── index.html
│── README.md
└── photos/
    └── laundry-image.jpg
```

## How to Run the Project

1. Download or clone the project.
2. Make sure the **photos** folder is present in the correct location.
3. Open the `index.html` file in any web browser.

## Future Improvements

* Add CSS for better styling.
* Make the website responsive.
* Add JavaScript form validation.
* Add online booking functionality.
* Integrate a backend and database.

## Author

Riya Kumari
